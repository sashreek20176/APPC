/**
 * Generated ArrowDB configuration for production
 */
module.exports = {
  "connectors": {
    "appc.arrowdb": {
      "enabled": true,
      "connector": "appc.arrowdb",
      "environment": "production",
      "key": "qXZuIOJRrUbjWVViiYwERgezPOpd80GU",
      "baseurl": "https://api.cloud.appcelerator.com",
      "username": "appc_app_user",
      "password": "xdi0OpnSbYm03sw2GV"
    }
  }
};