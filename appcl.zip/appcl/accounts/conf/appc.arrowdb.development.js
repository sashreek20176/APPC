/**
 * Generated ArrowDB configuration for development
 */
module.exports = {
  "connectors": {
    "appc.arrowdb": {
      "enabled": true,
      "connector": "appc.arrowdb",
      "environment": "development",
      "key": "v9dwu6Fq9T4uoeCYdZssgbgEve2nGqVz",
      "baseurl": "https://api.cloud.appcelerator.com",
      "username": "appc_app_user_dev",
      "password": "xvxZ02frq6bg0A5gUq"
    }
  }
};