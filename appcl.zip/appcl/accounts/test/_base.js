'use strict';

var Arrow = require('arrow'),
	server = new Arrow({
		port: 0
	});

exports.server = server;
